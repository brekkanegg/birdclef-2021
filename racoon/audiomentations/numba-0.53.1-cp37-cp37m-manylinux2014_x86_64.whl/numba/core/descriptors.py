"""
Target Descriptors
"""


class TargetDescriptor(object):
    pass
